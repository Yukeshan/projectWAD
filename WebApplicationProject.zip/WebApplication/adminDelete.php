<?php 
			$con = mysqli_connect("localhost:3308","root","","creativeLab");

	if(!$con)
	{
			die("Can not connect to DB Server");
	}

		
	$sql = "DELETE FROM tblproduct WHERE `tblproduct`.`ProductID` = ".$_GET['id'];
	
	mysqli_query($con,$sql);
header('Location:editProduct.php');

	
		
?>