<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link type="text/css" rel="stylesheet" href="style.css">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" /> <!-- search icon-->
	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" /> <!-- login icon -->
	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" /> <!-- cart icon -->
	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" /> <!-- heart icon -->
		<link rel="icon" href="Images/LogoOnly.png" type="image/png">
<title>Contact Us</title>
</head>

<body>
<div class="main">

	<header class="header">

	    <div class="logo">
			<a href="home.php"><img src="Images/LogoAndName.png">
			</a>
		</div>

		<div class="nav">
		<a href="home.php">Home</ahref="home.html">
		<a href="poducts.php">Products</a>
		<a href="signup.php">Sign Up</a>
		<a href="contactus.php" class="active">Contact Us</a>
		<a href="policy.php">Privacy Policy</a>
		<a href="Account.php">My Account</a>
		</div>

		<div class="miniIcons">
			<a href="home.php"><span class="material-symbols-outlined">
				home</span>
            </a>
			<a href="poducts.php"><span class="material-symbols-outlined">
				shopping_bag
				</span>
            </a>

			<a href="signup.php"><span class="material-symbols-outlined">
				app_registration
				</span>
            </a>

			<a href="contactus.php"><span class="material-symbols-outlined">
				call
				</span>
            </a>

			<a href="policy.php"><span class="material-symbols-outlined">
				security
				</span>
            </a>
		   </div>

		<div class="icons">

		<div class="icon1">
		<a href="Login.php"><span class="material-symbols-outlined">login
			        </span>
		</a>
	</div>
	</div>
		
</header>
<div class="content2">
<div class="contact_content">
	<h1>CONTACT US</h1>
	<div class="contact_content1"><h2>Thank You</h2><p>for your interest in Creative Lab, your ultimate destination for high-quality musical instruments and accessories. We are here to assist you and provide exceptional customer support. Please feel free to reach out to us using any of the following contact methods:</p>
</div>
	<div class="contact_content2"><p>Customer Support:<br>
Email: support@creativelabmusic.com<br>
Phone: +94 (77) 9977999<br>
<br>
Sales Inquiries:<br>
Email: sales@creativelabmusic.com<br>
Phone: +94 (77) 9977000<br>
<br>
General Inquiries:<br>
Email: info@creativelabmusic.com<br>
<br>
Our Office Address:<br>
No : 11,<br>
Creative Lab Music,<br>
Melody Lane,<br>
Battcaloa, Eastern Province, Sri Lanka.<br>
Postel Code : 30000<br>
<br>
Store Hours:<br>
Monday - Friday: 9:00 AM to 6:00 PM (GMT+5:30)<br>
Saturday: 10:00 AM to 4:00 PM (GMT+5:30)<br>
Sunday: Closed</p>
</div>
	
	<div class="contact_content3"><p>
We strive to respond to all inquiries within 24 hours, excluding weekends and holidays. If you have any questions, concerns, or feedback, please don't hesitate to contact us. Our knowledgeable and friendly team will be delighted to assist you.<br><br>

You can also connect with us on social media:<br>
<br>
Facebook : facebook.com/creativelabmusic<br>
Instagram : instagram.com/creativelabmusic<br>
Twitter : twitter.com/creativelabmusic<br>
<br>
We appreciate your support and look forward to serving you at Creative Lab, where your musical journey begins.
</p>
</div>
	
</div>

</div>
	

<footer class="footer">
		<div class="footerleft">
			    <h3>Creative Lab </h3>
		        <a href="contactus.html"><p>Contact Us</p></a>
		        <a href="policy.html"><p>Privacy Policy</p></a>
		
	    </div>
		<div class="footerright">
		<img src="Images/LogoOnly.png">
	    </div>
</footer>

</div>
	
</body>
</html>
