<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link type="text/css" rel="stylesheet" href="style.css">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" /> <!-- search icon-->
	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" /> <!-- login icon -->
	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" /> <!-- cart icon -->
	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" /> <!-- heart icon -->
		<link rel="icon" href="Images/LogoOnly.png" type="image/png">
<title>Products</title>
</head>

<body>
<div class="main">

	<header class="header">

	    <div class="logo">
			<a href="home.php"><img src="Images/LogoAndName.png">
			</a>
		</div>

		<div class="nav">
		<a href="home.php">Home</ahref="home.html">
		<a href="poducts.php" class="active">Products</a>
		<a href="signup.php">Sign Up</a>
		<a href="contactus.php">Contact Us</a>
		<a href="policy.php">Privacy Policy</a>
		<a href="Account.php">My Account</a>
		</div>

		<div class="miniIcons">
			<a href="home.php"><span class="material-symbols-outlined">
				home</span>
            </a>
			<a href="poducts.php"><span class="material-symbols-outlined">
				shopping_bag
				</span>
            </a>

			<a href="signup.php"><span class="material-symbols-outlined">
				app_registration
				</span>
            </a>

			<a href="contactus.php"><span class="material-symbols-outlined">
				call
				</span>
            </a>

			<a href="policy.php"><span class="material-symbols-outlined">
				security
				</span>
            </a>
		   </div>

		<div class="icons">
			<div class="icon1">
		<a href="cart.php"><span class="material-symbols-outlined">shopping_cart</span>
		</a>
	</div>
		<div class="icon1">
		<a href="Login.php"><span class="material-symbols-outlined">login
			        </span>
		</a>
	</div>
	</div>
		
</header>


<div class="content2">
	
	<h1>KEYBOARDS</h1>
<div class="productrow">
	
	<a href="#">
     <div class="product">
     <div class="top"><img src="Images/Products/Piano/Casio CDP-S110 Electric Piano.jpg"></div>
     <div class="bottom"><h3>Casio CDP-S110 Electric</h3><h4>80,000 LKR</h4><button href="#">Add To Cart<span class="material-symbols-outlined">shopping_cart                 
			</span>
			</button></div>
     </div>
	</a>

	<a href="#">
     <div class="product">
     <div class="top"><img src="Images/Products/Piano/Roland GP609.jpg"></div>
     <div class="bottom"><h3>Roland GP609</h3><h4>330,000 LKR</h4><button href="#">Add To Cart<span class="material-symbols-outlined">shopping_cart                 
			</span>
			</button></div>
     </div>
	</a>

	<a href="#">
     <div class="product">
     <div class="top"><img src="Images/Products/Piano/Steinway And Sons K-132PE.png"></div>
     <div class="bottom"><h3>Steinway K-132PE</h3><h4>840,000 LKR</h4><button href="#">Add To Cart<span class="material-symbols-outlined">shopping_cart                 
			</span>
			</button></div>
     </div>
	</a>
	
</div>
<div class="productrow">
	
	<a href="#">
     <div class="product">
     <div class="top"><img src="Images/Products/Piano/Suzuki MDG330.jpg"></div>
     <div class="bottom"><h3>Suzuki MDG330</h3><h4>230,000 LKR</h4><button href="#">Add To Cart<span class="material-symbols-outlined">shopping_cart                 
			</span>
			</button></div>
     </div>
	</a>

	<a href="#">
     <div class="product">
     <div class="top"><img src="Images/Products/Piano/Yamaha CLP765GP.png"></div>
     <div class="bottom"><h3>Yamaha CLP765GP</h3><h4>320,000 LKR</h4><button href="#">Add To Cart<span class="material-symbols-outlined">shopping_cart                 
			</span>
			</button></div>
     </div>
	</a>

	<a href="#">
     <div class="product">
     <div class="top"><img src="Images/Products/Piano/Yamaha P45 Electric Piano.jpg"></div>
     <div class="bottom"><h3>Yamaha P45 Electric</h3><h4>95,000 LKR</h4><button href="#">Add To Cart<span class="material-symbols-outlined">shopping_cart                 
			</span>
			</button></div>
     </div>
	</a>
	
</div>
	
	
	
	<h1>GUITARS</h1>
<div class="productrow">
	
	<a href="#">
     <div class="product">
     <div class="top"><img src="Images/Products/Guitar/Aria STG4.jpg"></div>
     <div class="bottom"><h3>Aria STG4</h3><h4>110,000 LKR</h4><button href="#">Add To Cart<span class="material-symbols-outlined">shopping_cart                 
			</span>
			</button></div>
     </div>
	</a>

	<a href="#">
     <div class="product">
     <div class="top"><img src="Images/Products/Guitar/Fender CD60S.jpg"></div>
     <div class="bottom"><h3>Fender CD60S</h3><h4>65,000 LKR</h4><button href="#">Add To Cart<span class="material-symbols-outlined">shopping_cart                 
			</span>
			</button></div>
     </div>
	</a>

	<a href="#">
     <div class="product">
     <div class="top"><img src="Images/Products/Guitar/Jackson KVXT.jpg"></div>
     <div class="bottom"><h3>Jackson KVXY</h3><h4>220,000 LKR</h4><button href="#">Add To Cart<span class="material-symbols-outlined">shopping_cart                 
			</span>
			</button></div>
     </div>
	</a>
	
</div>
<div class="productrow">
	
	<a href="#">
     <div class="product">
     <div class="top"><img src="Images/Products/Guitar/Martin Accoustic 16.jpg"></div>
     <div class="bottom"><h3>Martin Accoustic 16</h3><h4>85,000 LKR</h4><button href="#">Add To Cart<span class="material-symbols-outlined">shopping_cart                 
			</span>
			</button></div>
     </div>
	</a>

	<a href="#">
     <div class="product">
     <div class="top"><img src="Images/Products/Guitar/Yamaha F310.jpg"></div>
     <div class="bottom"><h3>Yamaha F310</h3><h4>60,000 LKR</h4><button href="#">Add To Cart<span class="material-symbols-outlined">shopping_cart                 
			</span>
			</button></div>
     </div>
	</a>

	<a href="#">
     <div class="product">
     <div class="top"><img src="Images/Products/Guitar/Yamaha Pacifica12.jpg"></div>
     <div class="bottom"><h3>Yamaha Pacifica12</h3><h4>190,000 LKR</h4><button href="#">Add To Cart<span class="material-symbols-outlined">shopping_cart                 
			</span>
			</button></div>
     </div>
	</a>
	
</div>
<h1>DRUMS</h1>
<div class="productrow">
	
	<a href="#">
     <div class="product">
     <div class="top"><img src="Images/Products/Drums/Alesis Electric Kit.jpg"></div>
     <div class="bottom"><h3>Alesis Electric Kit</h3><h4>218,000 LKR</h4><button href="#">Add To Cart<span class="material-symbols-outlined">shopping_cart                 
			</span>
			</button></div>
     </div>
	</a>

	<a href="#">
     <div class="product">
     <div class="top"><img src="Images/Products/Drums/Pearl Roadshow Junior.jpg"></div>
     <div class="bottom"><h3>Pearl Roadshow Junior</h3><h4>92,000 LKR</h4><button href="#">Add To Cart<span class="material-symbols-outlined">shopping_cart                 
			</span>
			</button></div>
     </div>
	</a>

	<a href="#">
     <div class="product">
     <div class="top"><img src="Images/Products/Drums/Roland VAD506V.jpg"></div>
     <div class="bottom"><h3>Roland VAD506V</h3><h4>345,000 LKR</h4><button href="#">Add To Cart<span class="material-symbols-outlined">shopping_cart                 
			</span>
			</button></div>
     </div>
	</a>
	
</div>

	
<h1>FLUTES</h1>
<div class="productrow">
	
	<a href="#">
     <div class="product">
     <div class="top"><img src="Images/Products/Flute/Carnatic Flute.jpg"></div>
     <div class="bottom"><h3>Carnatic Flute</h3><h4>28,000 LKR</h4><button href="#">Add To Cart<span class="material-symbols-outlined">shopping_cart                 
			</span>
			</button></div>
     </div>
	</a>

	<a href="#">
     <div class="product">
     <div class="top"><img src="Images/Products/Flute/Indian Bansuri Flute.jpg"></div>
     <div class="bottom"><h3>Indian Bansuri Flute</h3><h4>23,000 LKR</h4><button href="#">Add To Cart<span class="material-symbols-outlined">shopping_cart                 
			</span>
			</button></div>
     </div>
	</a>

	<a href="#">
     <div class="product">
     <div class="top"><img src="Images/Products/Flute/LD Western Flute.jpg"></div>
     <div class="bottom"><h3>LD Western Flute</h3><h4>38,000 LKR</h4><button href="#">Add To Cart<span class="material-symbols-outlined">shopping_cart                 
			</span>
			</button></div>
     </div>
	</a>
	
</div>
	
<h1>ACCESSORIES</h1>
<div class="productrow">
	
	<a href="#">
     <div class="product">
     <div class="top"><img src="Images/Products/Accessories/Focusrite 2i2 Audio Interface.jpg"></div>
     <div class="bottom"><h3>Focusrite 2i2 Interface</h3><h4>64,000 LKR</h4><button href="#">Add To Cart<span class="material-symbols-outlined">shopping_cart                 
			</span>
			</button></div>
     </div>
	</a>

	<a href="#">
     <div class="product">
     <div class="top"><img src="Images/Products/Accessories/Rode SM6 Filter.jpg"></div>
     <div class="bottom"><h3>Rode SM6 Filter</h3><h4>11,000 LKR</h4><button href="#">Add To Cart<span class="material-symbols-outlined">shopping_cart                 
			</span>
			</button></div>
     </div>
	</a>

	<a href="#">
     <div class="product">
     <div class="top"><img src="Images/Products/Accessories/Shure SM7B Kit.jpg"></div>
     <div class="bottom"><h3>Shure SM7B Kit</h3><h4>275,000 LKR</h4><button href="#">Add To Cart<span class="material-symbols-outlined">shopping_cart                 
			</span>
			</button></div>
     </div>
	</a>
	
</div>

	
	
	
	
</div>
<footer class="footer">
		<div class="footerleft">
			    <h3>Creative Lab </h3>
		        <a href="contactus.html"><p>Contact Us</p></a>
		        <a href="policy.html"><p>Privacy Policy</p></a>
		
	    </div>
		<div class="footerright">
		<img src="Images/LogoOnly.png">
	    </div>
</footer>

</div>
	
</body>
</html>
