#include <iostream>
using namespace std;
struct Exam{
    string ID;
    string subject; 
    double fee;
    int arr[7];
};

Exam getExamDetails(Exam e);
float calExamFee(double fee, int arr[], int size);


int main() {
    
    struct Exam efg;
    efg = getExamDetails(egf);
    calExamFee(egf);
    return 0;
}


Exam getExamDetails(Exam e){
    
    cout<<"ID"<<endl;
    cin>>e.ID;
    cout<<"subject"<<endl;
    cin>>e.subject;
    cout<<"fee"<<endl;
    cin>>e.fee;
    
    for(int i=0;i<7;i++){
        cout<<"Day"<<i+1<<"="<<endl;
        cin>>e.arr[i];
    }
    
}

Exam calExamFee(double fee, int arr[], int size){
    int num=0;
    double tfee;
    for(int i=0;i<7;i++){
        
        num = num+e.arr[i];
    }
    tfee=num*fee;
}