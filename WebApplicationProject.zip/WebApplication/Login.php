<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link type="text/css" rel="stylesheet" href="style.css">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" /> <!-- search icon-->
	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" /> <!-- login icon -->
	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" /> <!-- cart icon -->
	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" /> <!-- heart icon -->
		<link rel="icon" href="Images/LogoOnly.png" type="image/png">
<title>Log In</title>
</head>

<body>
<div class="main">

	<header class="header">

	    <div class="logo">
			<a href="home.php"><img src="Images/LogoAndName.png">
			</a>
		</div>

		<div class="nav">
		<a href="home.php">Home</a>
		<a href="poducts.php">Products</a>
		<a href="signup.php">Sign Up</a>
		<a href="contactus.php">Contact Us</a>
		<a href="policy.php">Privacy Policy</a>
		<a href="Account.php">My Account</a>
		</div>

		<div class="miniIcons">
			<a href="home.php"><span class="material-symbols-outlined">
				home</span>
            </a>
			<a href="poducts.php"><span class="material-symbols-outlined">
				shopping_bag
				</span>
            </a>

			<a href="signup.php"><span class="material-symbols-outlined">
				app_registration
				</span>
            </a>

			<a href="contactus.php"><span class="material-symbols-outlined">
				call
				</span>
            </a>

			<a href="policy.php"><span class="material-symbols-outlined">
				security
				</span>
            </a>
		   </div>

		<div class="icons">

		<div class="icon1">
		<a href="Login.php"><span class="material-symbols-outlined active">login
			        </span>
		</a>
	</div>
	</div>
		
</header>

<div class="content1">
<div class="logincontainer">
<form id="userloginform" name="userloginform" action="login.php" method="post">
<div class="userlogin">

<h2>User Login</h2>
<table width="400" border="0">
  <tbody>
    <tr>
      <td>Username</td>
      <td><input type="text" id="userloginname" name="userloginname" class="userloginname" required></td>
    </tr>
    <tr>
      <td>Password</td>
      <td><input type="password" id="userloginpassword" name="userloginpassword" class="userloginpassword" required></td>
    </tr>
	      <tr>
      <td colspan="2"><div class="loginbtns">
	<input type="submit" id="btnuserlogin" name="btnuserlogin" value="Login">
	<input type="reset" id="btnuserReset" name="btnuserReset" value="Reset">
</div></td>
    </tr>
  </tbody>
</table>

</div>
</form>
<p>
	<?php
	if(isset($_POST["btnuserlogin"]))
	{
		$username = $_POST["userloginname"];
		$password = $_POST["userloginpassword"];
		$valid = false;

		$con = mysqli_connect("localhost:3308","root","","creativeLab");

		if(!$con)
		{
			die("Can not connect to DB Server");
		}

		$sql = "SELECT * FROM `tbluser` WHERE `Email` = '".$username."' AND `Password` ='".$password."'";

		$result = mysqli_query($con,$sql);
		if(mysqli_num_rows($result)>0)
		{
			$valid = true;
		}
		else
		{
			$valid =false;
		}
	


		
		if($valid == true)
		{
			$_SESSION["username"] = $username;
			header('Location:Account.php');
		}
		else
		{
			echo "Please enter the correct username and password";
		}
		
	}
	?>
</p>




</div>

</div>

<footer class="footer">
		<div class="footerleft">
			    <h3>Creative Lab </h3>
		        <a href="contactus.html"><p>Contact Us</p></a>
		        <a href="policy.html"><p>Privacy Policy</p></a>
		
	    </div>
		<div class="footerright">
		<img src="Images/LogoOnly.png">
	    </div>
</footer>

</div>
	
</body>
</html>
