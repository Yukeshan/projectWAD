<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link type="text/css" rel="stylesheet" href="style.css">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" /> <!-- search icon-->
	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" /> <!-- login icon -->
	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" /> <!-- cart icon -->
	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" /> <!-- heart icon -->
	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" /> <!-- home icon -->
	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" /> <!-- shop icon -->
	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" /> <!-- registration icon -->
	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" /><!-- contact us icon -->
	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,400,0,0" />                   <!-- policy icon -->
	 
	<link rel="icon" href="Images/LogoOnly.png" type="image/png">


	<title>Home</title>

</head>

<body>
<div class="main">

	<header class="header">

	    <div class="logo">
			<a href="home.php"><img src="Images/LogoAndName.png">
			</a>
		</div>

		<div class="nav">
		<a href="home.php" class="active">Home</ahref="home.html">
		<a href="poducts.php">Products</a>
		<a href="signup.php">Sign Up</a>
		<a href="contactus.php">Contact Us</a>
		<a href="policy.php">Privacy Policy</a>
		<a href="Account.php">My Account</a>
		</div>

		<div class="miniIcons">
			<a href="home.php"><span class="material-symbols-outlined">
				home</span>
            </a>
			<a href="poducts.php"><span class="material-symbols-outlined">
				shopping_bag
				</span>
            </a>

			<a href="signup.php"><span class="material-symbols-outlined">
				app_registration
				</span>
            </a>

			<a href="contactus.php"><span class="material-symbols-outlined">
				call
				</span>
            </a>

			<a href="policy.php"><span class="material-symbols-outlined">
				security
				</span>
            </a>
		   </div>

		<div class="icons">

	</div>
		<div class="icon1">
		<a href="Login.php"><span class="material-symbols-outlined">login
			        </span>
		</a>
	</div>
	</div>
		
</header>
<div class="content1">
	
<div class="videocon">
<video autoplay muted loop playsinline class="video">
			<!- (1) autoplay = video plays automaticaly (2) muted = mute the sound (3) loop = video play again and again (4)playsinline = Mobile browsers, will play the video right where it is instead of opening it up in fullscreen while it plays->
		<source src="Videos/backVideo.mp4" type="video/mp4">
</video>
</div>
	<div class="maintext">
		<div class="leftside">
			<div class="first">
			<p>Music is a moral law. It gives soul to the universe, wings to the mind, flight to the imagination, and charm and gaiety to life and to everything.</p>
			</div>
			<div class="second">
				<h3>Get all kind of instruments at an affordable price.</h3>
			</div>
			<a href="poducts.html"><button>Shop Now <span class="material-symbols-outlined">shopping_cart                 
			</span>
			</button>
			</a>

		</div>
		<div class="rightside">
		<img src="Images/guitarist_signup.png">
		</div>
			
		</div>
	

</div>
	
<div class="content2">
	<h1>OUR TOP SELLING PRODUCTS</h1>
<div class="productrow">

	<a href="#">
     <div class="product">
     <div class="top"><img src="Images/Products/Piano/Roland GP609.jpg"></div>
     <div class="bottom"><h3>Roland GP609</h3><h4>330,000 LKR</h4><button href="#">Buy<span class="material-symbols-outlined">shopping_cart                 
			</span>
			</button></div>
     </div>
	</a>
	
	<a href="#">
     <div class="product">
     <div class="top"><img src="Images/Products/Guitar/Aria STG4.jpg"></div>
     <div class="bottom"><h3>Aria STG4</h3><h4>110,000 LKR</h4><button href="#">Buy<span class="material-symbols-outlined">shopping_cart                 
			</span>
			</button></div>
     </div>
	</a>

	<a href="#">
     <div class="product">
     <div class="top"><img src="Images/Products/Drums/Roland VAD506V.jpg"></div>
     <div class="bottom"><h3>Roland VAD506V</h3><h4>345,000 LKR</h4><button href="#">Buy<span class="material-symbols-outlined">shopping_cart                 
			</span>
			</button></div>
     </div>
	</a>
	
</div>
<div class="productrow">
	
		<a href="#">
     <div class="product">
     <div class="top"><img src="Images/Products/Flute/LD Western Flute.jpg"></div>
     <div class="bottom"><h3>LD Western Flute</h3><h4>38,000 LKR</h4><button href="#">Buy<span class="material-symbols-outlined">shopping_cart                 
			</span>
			</button></div>
     </div>
	</a>
	
	<a href="#">
     <div class="product">
     <div class="top"><img src="Images/Products/Accessories/Focusrite 2i2 Audio Interface.jpg"></div>
     <div class="bottom"><h3>Focusrite 2i2 Interface</h3><h4>64,000 LKR</h4><button href="#">Buy<span class="material-symbols-outlined">shopping_cart                 
			</span>
			</button></div>
     </div>
	</a>

	<a href="#">
     <div class="product">
     <div class="top"><img src="Images/Products/Piano/Yamaha CLP765GP.png"></div>
     <div class="bottom"><h3>Yamaha CLP765GP</h3><h4>320,000 LKR</h4><button href="#">Buy<span class="material-symbols-outlined">shopping_cart                 
			</span>
			</button></div>
     </div>
	</a>

	
</div>
</div>
<footer class="footer">
		<div class="footerleft">
			    <h3>Creative Lab </h3>
		        <a href="contactus.html"><p>Contact Us</p></a>
		        <a href="policy.html"><p>Privacy Policy</p></a>
		
	    </div>
		<div class="footerright">
		<img src="Images/LogoOnly.png">
	    </div>
</footer>

</div>
	
</body>
</html>
