

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link type="text/css" rel="stylesheet" href="style.css">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" /> <!-- search icon-->
	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" /> <!-- login icon -->
	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" /> <!-- cart icon -->
	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" /> <!-- heart icon -->
		<link rel="icon" href="Images/LogoOnly.png" type="image/png">
<title>Update Product</title>
</head>

<body>
<div class="main">

	<header class="header">

	    <div class="logo">
			<a href="home.php"><img src="Images/LogoAndName.png">
			</a>
		</div>

        <div class="nav">
		<a href="adminEdit.php">Admin Home</a>
		</div>


	</div>
		
</header>
	

	<div style="height: 1000px; background-color: aliceblue;">
		
		<section style="padding-top: 100px; padding-left: 100px;">
			
<?php 

				
		$con = mysqli_connect("localhost:3308","root","","creativeLab");

		if(!$con)
		{
			die("Can not connect to DB Server");
		}

		$sql = "SELECT * FROM `tblproduct` WHERE `ProductID` = ".$_GET['id'];

		$result = mysqli_query($con,$sql);
			
		if(mysqli_num_rows($result)>0)
		{
			$row= mysqli_fetch_assoc($result);
			$image = $row['ImagePath'];
			
?>
			
			
			
			<form action="adminEdit.php?id=<?php echo $_GET['id'];?>" method="post" enctype="multipart/form-data">	
		<table width="200" border="0" align="center">
		  <tbody>

		    <tr>
		      <td>Title</td>
		      <td><input type="text" id="txtProTitle" name="txtProTitle" class="adminloginname" value="<?php echo $row['Title']; ?>"></input></td>
	        </tr>
		    <tr>
		      <td>Description</td>
		      <td><input type="text" name="txtProDesc" id="txtProDesc" class="signupinputtxt" value="<?php echo $row['Description']; ?>"></textarea></td>
	        </tr>
		    <tr>
		      <td>Price</td>
		      <td><input type="text" id="txtProPrice" name="txtProPrice" class="adminloginname" value="<?php echo $row['Price']; ?>"></input></td>
	        </tr>
			    <tr>
		      <td>Category</td>
		      <td><input type="text" id="txtProCat" name="txtProCat" class="adminloginname" value="<?php echo $row['category']; ?>"></input></td>
	        </tr>
		    <tr>
		      <td>Image</td>
		      <td><input type="file" id="fileImage" name="fileImage"></input></td>
	        </tr> 

	      </tbody>
	  </table>

<div class="regibtns">
	<input type="submit" id="btnAddPro" name="btnAddPro" value="Update" onClick="validate()">
	<input type="reset" id="btnCancelPro" name="btnCancelPro" value="Cancel">
</div>

<?php 

		if(isset($_POST['btnAddPro']))
		{
			if(is_uploaded_file($_FILES['fileImage']['tmp_name']))
			{
					$image = "Images/uploads/".basename($_FILES["fileImage"]["name"]);
					move_uploaded_file($_FILES["fileImage"]["tmp_name"],$image);
			}
			
	$title= $_POST["txtProTitle"];
	$description= $_POST["txtProDesc"];
	$price= $_POST["txtProPrice"];
	$category = $_POST["txtProCat"];
			
			$con = mysqli_connect("localhost:3308","root","","creativeLab");

	if(!$con)
	{
			die("Can not connect to DB Server");
	}

		
	$sql = "UPDATE `tblproduct` SET `Title` = '".$title."', `Description` = '".$description
		."', `Price` = '".$price."', `category` = '".$category."', `ImagePath` = '".$image."' WHERE `tblproduct`.`ProductID` = ".$_GET['id'].";";
	
	if(mysqli_query($con,$sql))
	{
		echo "Product Updated successfully";
	}
	else
	{
		echo "Product not Updated. please try again";
	}
	
		}
?>




<?php 

		}
?>


		</form>

</section>



</div>
	
</body>
</html>

