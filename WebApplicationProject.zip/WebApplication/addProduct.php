

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link type="text/css" rel="stylesheet" href="style.css">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" /> <!-- search icon-->
	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" /> <!-- login icon -->
	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" /> <!-- cart icon -->
	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" /> <!-- heart icon -->
		<link rel="icon" href="Images/LogoOnly.png" type="image/png">
<title>Admin Page</title>
</head>

<body>
<div class="main">

	<header class="header">

	    <div class="logo">
			<a href="home.php"><img src="Images/LogoAndName.png">
			</a>
		</div>

        <div class="nav">
		<a href="Admin.php">Admin Home</a>
		</div>


	</div>
		
</header>
	

	<div style="height: 1000px; background-color: aliceblue;">
		
		<section style="padding-top: 100px; padding-left: 100px;">

			<form action="addProduct.php" method="post" enctype="multipart/form-data">	
		<table width="200" border="0" align="center">
		  <tbody>

		    <tr>
		      <td>Title</td>
		      <td><input type="text" id="txtProTitle" name="txtProTitle" class="adminloginname"></input></td>
	        </tr>
		    <tr>
		      <td>Description</td>
		      <td><textarea name="txtProDesc" id="txtProDesc" class="signupinputtxt"></textarea></td>
	        </tr>
		    <tr>
		      <td>Price</td>
		      <td><input type="text" id="txtProPrice" name="txtProPrice" class="adminloginname"></input></td>
	        </tr>
			    <tr>
		      <td>Category</td>
		      <td><input type="text" id="txtProCat" name="txtProCat" class="adminloginname"></input></td>
	        </tr>
		    <tr>
		      <td>Image</td>
		      <td><input type="file" id="fileImage" name="fileImage" ></input></td>
	        </tr> 

	      </tbody>
	  </table>

<div class="regibtns">
	<input type="submit" id="btnAddPro" name="btnAddPro" value="Add" onClick="validate()">
	<input type="reset" id="btnCancelPro" name="btnCancelPro" value="Cancel">
</div>
		</form>

</section>
<p>
<?php

if(isset($_POST["btnAddPro"]))
{
	$title= $_POST["txtProTitle"];
	$description= $_POST["txtProDesc"];
	$price= $_POST["txtProPrice"];
	$image = "Images/uploads/".basename($_FILES["fileImage"]["name"]);
	$category = $_POST["txtProCat"];
	
	
	$con = mysqli_connect("localhost:3308","root","","creativeLab");

	if(!$con)
	{
			die("Can not connect to DB Server");
	}
	
	move_uploaded_file($_FILES["fileImage"]["tmp_name"],$image);
	
	
	$sql = "INSERT INTO `tblproduct` (`ProductID`, `Title`, `Description`, `Price`, `ImagePath`, `category`) VALUES (NULL, '".$title."', '".$description."', '".$price."', '".$image."','".$category."');";
	
	if(mysqli_query($con,$sql))
	{
		echo "Product added successfully";
	}
	else
	{
		echo "Product not added. please try again";
	}
	
	
}

?>
</p>


</div>
	
</body>
</html>

