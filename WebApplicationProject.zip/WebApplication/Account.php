<?php
session_start();
if(!(isset($_SESSION["username"])))
{
	header('Location:login.php');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link type="text/css" rel="stylesheet" href="style.css">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" /> <!-- search icon-->
	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" /> <!-- login icon -->
	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" /> <!-- cart icon -->
	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" /> <!-- heart icon -->
		<link rel="icon" href="Images/LogoOnly.png" type="image/png">
<title>My Account</title>
</head>

<body>
<div class="main">

	<header class="header">

	    <div class="logo">
			<a href="home.php"><img src="Images/LogoAndName.png">
			</a>
		</div>

		<div class="nav">
		<a href="home.php">Home</a>
		<a href="poducts.php">Products</a>
		<a href="signup.php">Sign Up</a>
		<a href="contactus.php">Contact Us</a>
		<a href="policy.php">Privacy Policy</a>
		<a href="Account.php" class="active">My Account</a>
		</div>

		<div class="miniIcons">
			<a href="home.php"><span class="material-symbols-outlined">
				home</span>
            </a>
			<a href="poducts.php"><span class="material-symbols-outlined">
				shopping_bag
				</span>
            </a>

			<a href="signup.php"><span class="material-symbols-outlined">
				app_registration
				</span>
            </a>

			<a href="contactus.php"><span class="material-symbols-outlined">
				call
				</span>
            </a>

			<a href="policy.php"><span class="material-symbols-outlined">
				security
				</span>
            </a>
		   </div>

		<div class="icons">

		<div class="icon1">
		<a href="Login.php"><span class="material-symbols-outlined">login
			        </span>
		</a>
	</div>
	</div>
		
</header>
	

	<div style="height: 1000px; background-color: aliceblue;">
        
 
	<div class="content5" style="background-color: aliceblue;  align-items: center; justify-content: center;">
		<h1>Account</h1>

        <section class="user-info">
            <h2>Account Information</h2>
            <div class="user-details">
              <div class="avatar">
                <img src="Images/Account DP/pic.jpg">
              </div>
              <div class="user-name">
                <h3>Yukeshan Yoganathan</h3>
                <p>yjyukesh@gmail.com</p>
              </div>
            </div>
            <div class="edit-profile">
              <a href="#">Edit Profile</a>
            </div>
          </section>
      
          <section class="order-history">
            <h2>Order History</h2>
            <table cellspacing="20px">
              <thead>
                <tr>
                  <th>Order ID</th>
                  <th>Date</th>
                  <th>Total Amount</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>#18</td>
                  <td>2023-05-01</td>
                  <td>180,000 LKR</td>
                  <td>Delivered</td>
                </tr>
                <tr>
                  <td>#21</td>
                  <td>2023-04-15</td>
                  <td>230,000 LKR</td>
                  <td>Shipped</td>
                </tr>
              </tbody>
            </table>
          </section>


</div>
</div>
		




<footer class="footer">
		<div class="footerleft">
			    <h3>Creative Lab </h3>
		        <a href="contactus.html"><p>Contact Us</p></a>
		        <a href="policy.html"><p>Privacy Policy</p></a>
		
	    </div>
		<div class="footerright">
		<img src="Images/LogoOnly.png">
	    </div>
</footer>

</div>
	
</body>
</html>

