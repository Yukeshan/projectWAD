-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3308
-- Generation Time: Jul 20, 2023 at 05:32 PM
-- Server version: 8.0.31
-- PHP Version: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `creativelab`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblproduct`
--

DROP TABLE IF EXISTS `tblproduct`;
CREATE TABLE IF NOT EXISTS `tblproduct` (
  `ProductID` int NOT NULL AUTO_INCREMENT,
  `Title` varchar(30) NOT NULL,
  `Description` varchar(300) NOT NULL,
  `Price` int NOT NULL,
  `ImagePath` varchar(50) NOT NULL,
  `category` varchar(35) NOT NULL,
  PRIMARY KEY (`ProductID`)
) ENGINE=MyISAM AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `tblproduct`
--

INSERT INTO `tblproduct` (`ProductID`, `Title`, `Description`, `Price`, `ImagePath`, `category`) VALUES
(46, 'Jackson KVXY', 'Concert guitar', 300000, 'Images/uploads/Jackson KVXT.jpg', 'Guitar'),
(45, 'Fender CD60S', '6 String Accoustic Guitar', 65000, 'Images/uploads/Fender CD60S.jpg', 'Guitar'),
(44, 'Aria STG4', 'Electric Guitar', 110000, 'Images/uploads/Aria STG4.jpg', 'Guitar'),
(43, 'Alesis Electric', 'electric drum kit', 218000, 'Images/uploads/Alesis Electric Kit.jpg', 'Drums'),
(42, 'Pearl Roadshow', 'Junior drum kit', 92000, 'Images/uploads/Pearl Roadshow Junior.jpg', 'Drums'),
(41, 'Roland VAD506V', 'professional drum kit', 345000, 'Images/uploads/Roland VAD506V.jpg', 'Drums'),
(40, 'Carnatic Flute', 'indian classical flute', 28000, 'Images/uploads/Carnatic Flute.jpg', 'Flute'),
(39, 'Indian Bansuri Flute', 'Raga Based flute', 23000, 'Images/uploads/Indian Bansuri Flute.jpg', 'Flute'),
(38, 'LD Western Flute', 'Western scale flute', 38000, 'Images/uploads/LD Western Flute.jpg', 'Flute'),
(37, 'Shure SM7B', 'Shure Condenser Microphone Kit', 275000, 'Images/uploads/Shure SM7B Kit.jpg', 'Accessories'),
(36, 'Rode SM6', 'Pop Filter', 11000, 'Images/uploads/Rode SM6 Filter.jpg', 'Accessories'),
(35, 'Focusrite 2i2', 'Audio Interface', 64000, 'Images/uploads/Focusrite 2i2 Audio Interface.jpg', 'Accessories'),
(34, 'Casio CDP-S110', ' Electric Piano', 80000, 'Images/uploads/Casio CDP-S110 Electric Piano.jpg', 'piano'),
(29, 'Roland GP609', '88 keys vintage piano', 330000, 'Images/uploads/Roland GP609.jpg', 'piano'),
(50, 'Steinway And Sons K-132PE', 'Steinway And Sons Classical Piano', 840000, 'Images/uploads/Steinway And Sons K-132PE.png', 'piano'),
(31, 'Suzuki MDG330', 'western classic piano', 230000, 'Images/uploads/Suzuki MDG330.jpg', 'piano'),
(32, 'Yamaha CLP765GP', 'accousic piano with padels', 320000, 'Images/uploads/Yamaha CLP765GP.png', 'piano'),
(33, 'Yamaha P45', '61 Keys Electric Piano', 95000, 'Images/uploads/Yamaha P45 Electric Piano.jpg', 'piano'),
(47, 'Martin Accoustic 16', 'Legendary Martin \r\nAccoustic Guitar', 85000, 'Images/uploads/Martin Accoustic 16.jpg', 'Guitar'),
(48, 'Yamaha F310', '6 Strings Yamaha Accoustic Guitar', 60000, 'Images/uploads/Yamaha F310.jpg', 'Guitar'),
(49, 'Yamaha Pacifica12', 'Bass Guittar', 190000, 'Images/uploads/Yamaha Pacifica12.jpg', 'Guitar'),
(51, 'guitar', 'accoustic', 70000, 'Images/uploads/Fender CD60S.jpg', 'Guitar');

-- --------------------------------------------------------

--
-- Table structure for table `tbluser`
--

DROP TABLE IF EXISTS `tbluser`;
CREATE TABLE IF NOT EXISTS `tbluser` (
  `FullName` varchar(50) NOT NULL,
  `Email` varchar(35) NOT NULL,
  `Password` varchar(20) NOT NULL,
  `Phone` varchar(15) NOT NULL,
  `Address` varchar(150) NOT NULL,
  PRIMARY KEY (`Email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `tbluser`
--

INSERT INTO `tbluser` (`FullName`, `Email`, `Password`, `Phone`, `Address`) VALUES
('Yukeshan Yoganthan', 'yjyukesh@gmail.com', 'password', '0704545405', 'colombo'),
('Kalaiyarasan Kandasami', 'kalai@gmail.com', 'kalai', '1234567890', 'jaffna'),
('vickash', 'vicka@gmail.com', 'abc12345', '1234567890', 'hatton'),
('yukesh', 'yjyukes123@gmail.com', 'abcd1234', '1234567890', 'colombo');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
