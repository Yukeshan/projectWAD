<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link type="text/css" rel="stylesheet" href="style.css">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" /> <!-- search icon-->
	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" /> <!-- login icon -->
	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" /> <!-- cart icon -->
	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" /> <!-- heart icon -->
		<link rel="icon" href="Images/LogoOnly.png" type="image/png">
<title>Edit Products</title>
</head>

<body>
<div class="main">

<header class="header">

<div class="logo">
    <a href="home.php"><img src="Images/LogoAndName.png">
    </a>
</div>

<div class="nav">
<a href="Admin.php">Admin Home</a>
</div>


</div>

</header>


<div class="content2">
	
<div class="productrowgrid">
	
	
	<?php
	
		$con = mysqli_connect("localhost:3308","root","","creativeLab");

		if(!$con)
		{
			die("Can not connect to DB Server");
		}

		$sql = "SELECT * FROM `tblproduct`";

		$result = mysqli_query($con,$sql);
			
		if(mysqli_num_rows($result)>0)
		{
			while($row= mysqli_fetch_assoc($result))
			{
		


	
	?>
	
	<div class="product_grid">
    <a href="#">
        <div class="product">
        <div class="top"><img src="<?php echo $row['ImagePath']; ?>"></div>
        <div class="bottom"><h3><?php echo $row['Title']; ?></h3><h4><?php echo $row['Price']; ?> LKR</h4>
			<h5><?php echo $row['Description']; ?></h5>
			<a href="adminEdit.php?id=<?php echo $row['ProductID']; ?>"><h2>EDIT</h2></a> <h2>|</h2>
            <a href="adminDelete.php?id=<?php echo $row['ProductID']; ?>"><h2>DELETE</h2></a>
            </div>
        </div>
       </a>
</div>
	
	
	<?php
		}
	}
	
	mysqli_close($con);
	

	?>
	
	
	
</div>






<footer class="footer">
		<div class="footerleft">
			    <h3>Creative Lab </h3>
		        <a href="contactus.html"><p>Contact Us</p></a>
		        <a href="policy.html"><p>Privacy Policy</p></a>
		
	    </div>
		<div class="footerright">
		<img src="Images/LogoOnly.png">
	    </div>
</footer>

</div>
	
</body>
</html>
