<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link type="text/css" rel="stylesheet" href="style.css">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" /> <!-- search icon-->
	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" /> <!-- login icon -->
	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" /> <!-- cart icon -->
	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" /> <!-- heart icon -->
	<link rel="icon" href="Images/LogoOnly.png" type="image/png">
<title>Privacy Policy</title>
</head>

<body>
<div class="main">

	<header class="header">

	    <div class="logo">
			<a href="home.php"><img src="Images/LogoAndName.png">
			</a>
		</div>

		<div class="nav">
		<a href="home.php">Home</ahref="home.html">
		<a href="poducts.php">Products</a>
		<a href="signup.php">Sign Up</a>
		<a href="contactus.php">Contact Us</a>
		<a href="policy.php" class="active">Privacy Policy</a>
		<a href="Account.php">My Account</a>
		</div>

		<div class="miniIcons">
			<a href="home.php"><span class="material-symbols-outlined">
				home</span>
            </a>
			<a href="poducts.php"><span class="material-symbols-outlined">
				shopping_bag
				</span>
            </a>

			<a href="signup.php"><span class="material-symbols-outlined">
				app_registration
				</span>
            </a>

			<a href="contactus.php"><span class="material-symbols-outlined">
				call
				</span>
            </a>

			<a href="policy.php"><span class="material-symbols-outlined">
				security
				</span>
            </a>
		   </div>

		<div class="icons">

		<div class="icon1">
		<a href="Login.php"><span class="material-symbols-outlined">login
			        </span>
		</a>
	</div>
	</div>
		
</header>
<div class="content2">

	<div class="contact_content">
	<h1>PRIVACY POLICY</h1>
	<div class="contact_content1">
		<p>At Creative Lab, we value your privacy and are committed to protecting your personal information. This Privacy Policy explains how we collect, use, and safeguard the information you provide to us when you visit our website or make use of our services. By accessing or using Creative Lab's website, you agree to the practices described in this Privacy Policy.<br>
<br>
1. Information We Collect<br>
1.1 Personal Information<br>
We may collect personal information from you, such as your name, email address, phone number, shipping address, billing address, and payment details when you place an order or create an account on our website. We use this information to process your orders, provide customer support, and enhance your shopping experience.<br>
<br>
1.2 Log Data<br>
When you visit our website, our servers automatically record information that your browser sends. This may include your IP address, browser type, the pages you visit, the time and date of your visit, and other statistics. We use this information to analyze trends and administer the site.</p>
</div>
	<div class="contact_content2">
	<p>
2. How We Use Your Information<br>
2.1 Order Processing and Fulfillment<br>
We use the personal information you provide to process and fulfill your orders, communicate order status, and provide customer support related to your purchase.<br>
<br>
2.2 Improving Our Services<br>
We may use the information collected to improve our website, products, and services. This includes analyzing user behavior and preferences, conducting market research, and enhancing our marketing efforts.<br>
<br>
2.3 Communication<br>
We may use your contact information to send you promotional offers, updates about our products and services, and other relevant communications. You have the option to opt out of receiving marketing communications from us at any time.
	</p>
</div>
	
	<div class="contact_content3">
		<p>
3. Information Sharing<br>
3.1 We do not sell, trade, or rent your personal information to third parties for their marketing purposes. However, we may share your information with trusted third-party service providers who assist us in operating our website, conducting our business, and servicing your requests. These service providers are contractually obligated to keep your information confidential and are prohibited from using your personal data for any other purpose.<br>
<br>
We may also disclose your information when required by law, to protect our rights or the safety of others, or in response to a lawful request by public authorities.<br>
<br>
Changes to the Privacy Policy<br>
We reserve the right to update or modify this Privacy Policy at any time without prior notice. We will notify you of any changes by updating the "Effective Date" at the top of this policy. We encourage you to review this Privacy Policy periodically.<br>
		</p>
</div>
	
</div>
	

</div>
	
<footer class="footer">
		<div class="footerleft">
			    <h3>Creative Lab </h3>
		        <a href="contactus.html"><p>Contact Us</p></a>
		        <a href="policy.html"><p>Privacy Policy</p></a>
		
	    </div>
		<div class="footerright">
		<img src="Images/LogoOnly.png">
	    </div>
</footer>

</div>
	
</body>
</html>
