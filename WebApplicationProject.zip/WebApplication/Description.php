<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link type="text/css" rel="stylesheet" href="style.css">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" /> <!-- search icon-->
	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" /> <!-- login icon -->
	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" /> <!-- cart icon -->
	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" /> <!-- heart icon -->
		<link rel="icon" href="Images/LogoOnly.png" type="image/png">
<title>Description</title>
</head>

<body>
<div class="main">

	<header class="header">

	    <div class="logo">
			<a href="home.php"><img src="Images/LogoAndName.png">
			</a>
		</div>

		<div class="nav">
		<a href="home.php">Home</ahref="home.html">
		<a href="poducts.php">Products</a>
		<a href="signup.php">Sign Up</a>
		<a href="contactus.php">Contact Us</a>
		<a href="policy.php">Privacy Policy</a>
		<a href="Account.php">My Account</a>
		</div>

		<div class="miniIcons">
			<a href="home.php"><span class="material-symbols-outlined">
				home</span>
            </a>
			<a href="poducts.php"><span class="material-symbols-outlined">
				shopping_bag
				</span>
            </a>

			<a href="signup.php"><span class="material-symbols-outlined">
				app_registration
				</span>
            </a>

			<a href="contactus.php"><span class="material-symbols-outlined">
				call
				</span>
            </a>

			<a href="policy.php"><span class="material-symbols-outlined">
				security
				</span>
            </a>
		   </div>

		<div class="icons">

		<div class="icon1">
		<a href="Login.php"><span class="material-symbols-outlined active">login
			        </span>
		</a>
	</div>
	</div>
		
</header>
	
<div class="cart">
	
	<div class="content2">
		<h1>Roland GP609</h1>
	<div class="productrow">
	
		<a href="#">
		 <div class="product">
		 <div class="top"><img src="Images/Products/Piano/Roland GP609.jpg"></div>
		 <div class="bottom"><h3>Roland GP609</h3><h4>330,000 LKR</h4><button href="#">Add To Cart<span class="material-symbols-outlined">shopping_cart                 
        </span>
        </button>            </div>
        <p>The GP609 is a grand piano without compromise. You can experience the performance of a traditional acoustic grand, whose sound has been at the heart of music for over 300 years. And you also get to explore the endless creative possibilities offered by the latest digital technology. Since creating the worlds first touch-sensitive electronic piano in 1974, Roland has become a leader in digital piano innovation and the new GP609 embodies our belief that advanced technology and know-how can take your music further.</p>
    
		 </div>
		</a>

        </div>

		




<footer class="footer">
		<div class="footerleft">
			    <h3>Creative Lab </h3>
		        <a href="contactus.html"><p>Contact Us</p></a>
		        <a href="policy.html"><p>Privacy Policy</p></a>
		
	    </div>
		<div class="footerright">
		<img src="Images/LogoOnly.png">
	    </div>
</footer>

</div>
	
</body>
</html>
