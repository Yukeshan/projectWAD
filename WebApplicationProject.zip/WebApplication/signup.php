<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link type="text/css" rel="stylesheet" href="style.css">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" /> <!-- search icon-->
	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" /> <!-- login icon -->
	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" /> <!-- cart icon -->
	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" /> <!-- heart icon -->
	<script>
	
		function validateFullName()
		{
			var fName = document.getElementById("txtName").value;
			if(fName==""||fName== null)
			   {
					alert("Please Enter The Full Name");
					return false;
			   }
			return true;
		}
		
		
				function validateEmail()
		{
			var email = document.getElementById("txtEmail").value;
			var at = email.indexOf("@");
			var dot = email.lastIndexOf(".");
			var emailLength = email.length;
			
			if((at<2)||(dot-at<2)||(emailLength-dot<2))
			   {
					alert("Enter valid email address");
					return false;
			   }
			
			else
			   {
				return true;
			   }
		}
			
			function validatePassword()
			{
				var password = document.getElementById("txtPassword").value;
				var cPassword = document.getElementById("txtCPassword").value;
				var passwordLength = password.length;
				
				if((passwordLength)<6||(password!=cPassword))
				{
					alert("Please enter a correct password and password should match with confirm password");
						return false;
					
				}
				else
				{
					return true;
					
				}
				
			}
		
		
		
		function validateConNum()
		{
			var contactNumber=document.getElementById("txtConNum").value;
			if(contactNumber.length!=10||isNaN(contactNumber))
				{
					alert("Please give a valid contact number");
					return false;
		        }
			else
			    {
				return true;
			    }
			
			
		}
		
			

			
			
		
		
		
		function validate()
		{
			if(validateFullName()&&validateEmail()&&validatePassword()&&validateConNum())
				{
					alert("Reservation has been added");
				}
			else
			{
				event.preventDefault();
			}
			
		}
		
		
	
	</script>
	
	
	
	<link rel="icon" href="Images/LogoOnly.png" type="image/png">
<title>Sign Up</title>
</head>

<body>
<div class="main">

	<header class="header">

	    <div class="logo">
			<a href="home.php"><img src="Images/LogoAndName.png">
			</a>
		</div>

		<div class="nav">
		<a href="home.php">Home</ahref="home.html">
		<a href="poducts.php">Products</a>
		<a href="signup.php" class="active">Sign Up</a>
		<a href="contactus.php">Contact Us</a>
		<a href="policy.php">Privacy Policy</a>
		<a href="Account.php">My Account</a>
		</div>

		<div class="miniIcons">
			<a href="home.php"><span class="material-symbols-outlined">
				home</span>
            </a>
			<a href="poducts.php"><span class="material-symbols-outlined">
				shopping_bag
				</span>
            </a>

			<a href="signup.php"><span class="material-symbols-outlined">
				app_registration
				</span>
            </a>

			<a href="contactus.php"><span class="material-symbols-outlined">
				call
				</span>
            </a>

			<a href="policy.php"><span class="material-symbols-outlined">
				security
				</span>
            </a>
		   </div>

		<div class="icons">

		<div class="icon1">
		<a href="Login.php"><span class="material-symbols-outlined">login
			        </span>
		</a>
	</div>
	</div>
		
</header>

<div class="content3">
	
<div class="cont3left">
		<form method="post" id="signupForm" name="signupForm" action="signup.php">
	<!-- since we want to get input we should write all the tags which are going to take inputs from user in the form tag -->

<table class="formTable" >
<tbody>
<tr><td colspan="2"><h3>Please Fill This Form To Register</h3></td></tr>
<tr><td>Full Name : </td><td><input type="text" name="txtName" id="txtName" class="signupinput"></td></tr>
<tr><td>Email Address : </td><td><input type="email" id="txtEmail" name="txtEmail" class="signupinput"></td></tr>
<tr><td>Password : </td><td><input type="password" id="txtPassword" name="txtPassword" class="signupinput"></td></tr>
<tr><td>Confirm Password : </td><td><input type="password" id="txtCPassword" name="txtCPassword" class="signupinput"></td></tr>
<tr><td>Contact Number : </td><td><input type="text" name="txtConNum" id="txtConNum" class="signupinput"></td></tr>
<tr><td>Conctact Address : </td><td><textarea id="txtAddress" name="txtAddress" class="signupinputtxt"></textarea></td></tr>	
			
</tbody>
</table>
			
<div class="regibtns">
	<input type="submit" id="btnSubmit" name="btnSubmit" value="Submit" onClick="validate()">
	<input type="reset" id="btReset" name="btnReset" value="Reset">
</div>			

</form>

<?php
if(isset($_POST["btnSubmit"]))
{
	$fullName = $_POST["txtName"];
	$email = $_POST["txtEmail"];
	$Password = $_POST["txtPassword"];
	$contact = $_POST["txtConNum"];
	$address = $_POST["txtAddress"];

	$con = mysqli_connect("localhost:3308","root","","creativeLab");

	if(!$con)
	{
		die("Can not connect to DB Server");
	}

	$sql="INSERT INTO `tbluser` (`FullName`, `Email`, `Password`, `Phone`, `Address`) VALUES ('".$fullName."', '".$email."', '".$Password."', '".$contact."', '".$address."');";

	mysqli_query($con,$sql);

}

?>


</div>
	
	

	
</div>
	
	
<footer class="footer">
		<div class="footerleft">
			    <h3>Creative Lab </h3>
		        <a href="contactus.html"><p>Contact Us</p></a>
		        <a href="policy.html"><p>Privacy Policy</p></a>
		
	    </div>
		<div class="footerright">
		<img src="Images/LogoOnly.png">
	    </div>
</footer>

</div>
	
</body>
</html>
